# WABS plugin SDK

Version 0.3.18 supplies portable plugin manifests, service declarations, command parsing and registration, assistant tool contracts, archive export contracts, durable flow and state interfaces, metadata-driven console controls, conditional templates, workflows, ephemeral storage and IANA timezone validation. Runtime services, account ownership and persistence stay in WABP and are passed through plugin contexts. The SDK never imports host source, production configuration or optional plugins.

Console providers declare `consoleOperations` in signed package metadata and register their handlers through `registerConsoleOperations`. `PluginConsoleContext` fixes the account, runtime and owning plugin for each invocation. It supplies owned configuration reads, updates and compare-and-set, declared databases, account group lookup, scope clocks, audit and declared runtime actions. Read operations open SQLite in native read-only mode; resource-token routes cannot acquire operator or mutation authority. The provider validates its resource token and payload. WABP loads the installed provider and manager from the same catalog snapshot and keeps database resources open until the operation settles. Plugins using this interface require core API `^0.3.4` or a later compatible range.

Core API `^0.3.5` adds account-checked scope ancestry, descendant lookup and console archive capabilities. The host rechecks chat coverage on every export and fixes the authenticated actor and maximum document size. Archive capture can add the selected scope while preserving existing coverage, privacy and retention settings. `configuration.scopeEnabledOperationId` names an owned, declared operator mutation to run after scope enablement; its output is returned as `scopeEnabledResult`. Providers decide whether their saved settings call for preparation. Resource-token routes cannot use archive capabilities.

The optional `identityAccess` capability binds membership lookup to the host's account, runtime and calling plugin. It returns stable identities and enabled scope memberships, with raw enabled configuration layers in inheritance order for preserving existing plugin merge contracts. It cannot query another plugin's configuration or resolve a WhatsApp address. Federated subject resolution requires current plugin membership and the runtime's configured issuer; the host retains verified identity and revocation authority. Managed plugins can register declared external actions through the same portable runtime capabilities.

Managed group plugins receive `ManagedGroupCommandContext`, `ManagedGroupRuntimeContext` and `ManagedGroupServiceContext`. The host supplies authorized group, archive and workflow operations. Group creation errors preserve uncertainty, completed creation checkpoints and recovery details across installed packages. Plugins must continue from those checkpoints and must not retry an uncertain creation as a new group. Lifecycle hooks receive only plugin-owned state and declared databases. A `resolveGroupTimezone` provider can expose a persisted resource timezone for a group in the requested scope; the host checks account and scope ownership before using it.

Durable plugins receive database and workflow interfaces through `DurablePluginCommandContext`, `DurablePluginRuntimeContext` and `DurablePluginServiceContext`. The host owns SQLite connections, migrations, workflow persistence, flow execution and transport effects. Plugins schedule their declared jobs through the host-bound `enqueuePluginJob` capability, which fixes the owning plugin ID. Poll readback, transport error classification, message IDs, date parsing and flow input reducers use shared pure helpers. Typed transport errors retain their identity across separately installed SDK copies, including delivery uncertainty and readback completeness.

Integration plugins use host-provided configuration, media storage and job scheduling. OAuth client-credentials helpers operate only on explicitly supplied connection settings. Shared scope clocks and resource timezones are injected through `clockFor`; a plugin's `scopeClock.timezoneConfigPaths` declares derived defaults, while event-specific timezone snapshots remain resource data.

Stateful commands receive `StatefulPluginCommandContext`, with plugin-owned storage and a host flow engine. Flow definitions, snapshots, prompt locks and delivery metadata share canonical types with WABP. `CommunityCommandPluginContext` and `CommunityServicePluginContext` expose subgroup lookup and creation capabilities; account ownership, authoritative creator identity, lifecycle transactions and transport mutations stay in the host. The host retains the assistant execution context; the SDK only carries its ownership schema and pure helpers.

Archive consumers use `ArchiveHookPluginContext` with `HookPlugin<ArchiveHookPluginContext>`. The host supplies archive exports, recipient locale resolution and diagnostics. The SDK contains document metadata and bounded-delivery contracts; archive queries, authorization, rendering and filesystem access stay in WABP. Oversize export errors remain recognizable across independently installed SDK copies.

Service providers use `ServicePlugin` and `ServicePluginContext`; implement only the capabilities they need. Hook providers use `HookPlugin` and `PluginHookContext`, returning declared actions for the host to authorize and execute. Command providers use `CommandPlugin` and its registration context; command routing, guards and response delivery stay in WABP. Assistant tools share canonical descriptors and results; their portable context exposes caller identity, scope, locale and cancellation. Diagnostics use the injected logger. Cancellation and service pre-invocation errors remain recognizable across independently installed SDK copies. Portable event, transport, actor and group lifecycle contracts share canonical definitions with WABP. Stateful lifecycle context extraction is in progress. Plugins continue to declare their `coreApiRange` and exact package dependencies. Shared metadata cannot grant lifecycle or deployment authority.

Build with the repository's pinned TypeScript compiler: `npm run plugin-sdk:build`. Publication must include the compiled runtime, declarations, license and exact dependency lock.

Core API 0.3.1 adds `onRuntimeReady` for installed plugin recovery after host identity verification and before worker startup. Hooks receive `firstReadyForIdentity` and `startupBeforeWorker`; the host acknowledges readiness only after that plugin succeeds, retries failed recovery, and drains pending hooks on shutdown. Hook contexts expose owner-bound enabled scopes and job scheduling. Plugins using these capabilities must require `^0.3.1` or a later compatible core.

`ManagedGroupExternalActionContext` supplies host-bound command and runtime contexts for declared operator actions. The authenticated account administration endpoint retains its existing URLs; providers own input schemas and domain behavior. Recovery actions may operate on the plugin's persisted account resources even when a scope is disabled. Identity correlation and transport link probes remain host operations; a plugin supplies the persisted stable identity and participant checkpoint, and cannot manufacture evidence.

Core API 0.3.2 adds `PluginOperatorActionContext` for hook plugins' declared admin actions. Its `operator` capability filters audit history by the calling plugin and owned scope, checks current group coverage and management mode before executing plugin actions, and bounds archive exports to covered account chats. The host fixes the action owner and manifest; provider input cannot substitute them or authorize an unrelated group. This capability exists only on the authenticated administration registration context, not on ordinary message hooks.

Core API 0.3.3 adds signed `configuration` metadata. `changedActionId` must name the plugin's declared account mutation action; the console coalesces repeated changes separately for each runtime and plugin, without interrupting autosave. `permissionDeclarations` derives permission identifiers from validated array entries and never grants them to a principal. Controls may use `ui.defaultSource: "community-announcement-group"` for a contextual default. The host registers loaded controls against the exact manifest object, so assistant configuration summaries use installed metadata and its secret-redaction declarations. Shared checked-template and optional-name helpers keep previews consistent with plugin output.

## Typed message templates and mentions

Core API 0.3.6 and SDK 0.3.16 add the opt-in `conditional-values-v2` dialect.
Existing presence helpers retain their original behavior. Declare `valueType`,
canonical enum `options`, and optional raw `conditionSampleValue` on condition
fields. Display substitutions and `conditionValues` are separate: a translated
label such as “Privado” can have the canonical choice value `private`.

```text
{{#if ballotDelivery == "private"}}Check your private chat.{{else}}Vote here.{{/if}}
{{#if (count >= 2 && open == true)}}Ready.{{/if}}
{{#if (available(notice) || ballotDelivery in ["group"])}}{notice}{{/if}}
```

Comparisons are exact and do not coerce types. Missing values fail comparisons,
including negative comparisons. `false` and `0` are available. A legacy bare
`{{#if token}}` still tests the display string's presence. Expressions support
ALL/ANY groups, finite numeric thresholds, text matching and enumerated choices;
they never execute JavaScript. Use the shared parse, validation, rename and block
editing helpers instead of string replacement.

Declare `templateMentions` only on WhatsApp message bodies and captions. Fixed
people use stable identity IDs; groups use group JIDs. Native all-members mentions
and named group links are distinct. Example persisted source:

```text
{{mention person "identity-id" "Ana"}}
{{mention group "123@g.us" "Community walks"}}
{{mention target "creator" "Creator"}}
{{mention all}}
```

`renderValueTemplate` returns a `TemplateFragment`. Pass nested fragments as
substitution values, then resolve only the final fragment with
`resolvePluginTemplateMentions` or `resolveTemplateMentions`. Paginate with
`paginateResolvedTemplate` and persist each page's text and mention metadata
together before delivery. Do not parse interpolated display text as template
source. Plain-text destinations use `renderValueTemplateText`, which rejects
surviving mentions. `{{default}}` expands a supplied localized default fragment
without freezing a locale into configuration; recursive defaults are rejected.

The shared resolver marks new bodies with `inlineMentions`; preserve this flag with
the recipient metadata in actions, outbox rows and retry records. Transports use it
to keep mention tokens atomic and recipients local to each page. Old queued sends
without the flag retain their original chunk boundaries and recipient behavior.

Controls declare `ui.templateDialect`, `templateConditionVariables` and
`templateMentions`. Metadata-driven custom builders use `builderTemplateDialect`
and `builderTemplateMentions`; older installed plugins continue using their
original editor contract. Mention lookup requires the current account, runtime,
plugin and scope. The host checks group coverage before using cached contacts.

Lifecycle-only `migrateConfiguration` transforms owned configuration layers in a
serializable transaction. The host backs up original scope and identity layers
with the migration key before applying changes; repeating that key is a no-op.
It does not grant runtime hooks or console resources migration authority.

## Shared flow navigation (core API 0.3.7)

Set `navigationControls: true` on new definitions and declare `navigation.skip: 'unreserved-symbols'` on optional steps. The platform renders localized help and a separate menu control, accepts `/skip`, and skips symbol-only replies such as `.` unless a registered shortcut, label or alias owns the reply. `/keep` and `=` are reserved for keeping and never skip. An unavailable control reports an error and leaves the question open. Legacy `skipOnSymbolInput` definitions retain their old behavior.

For edits, declare `navigation.keep: { value, label }` with the original saved answer; use `null` for an omitted text answer and `[]` for an omitted choice. The host snapshots these descriptors when the session starts and retains them through edits, Back and reload. Ordinary text validators run on kept strings; use `resolveKeptInput` or `resolveKeptInputAsync` for typed answers and cross-field validation. A rejected saved value keeps the step open. Keep/Skip options are exclusive controls with reserved IDs, scoped to the owning flow, runtime and identity; business choice numbers keep their order. Persist a definition recipe and register a resolver for flows that must recover after process restart.

Core API 0.3.8 adds optional runtime `pinMessage`, `unpinMessage`, and `editMessage` capabilities. Edits remain owned by whatsmeow and preserve the existing message ID.
